#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=ec6f895e75482606f6c28a2f4a7538b6
dev/api/spec/com.ibm.ws.javaee.transaction.1.2_1.0.14.jar=f019c6d75bb1fcaf08033bd0e81a2bae
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.14.jar=64a83fd909a98a23d97db131630a9a0b
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=75191880e7139bd7d6ad53c10a05b1fc
