#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jca-1.7.mf=b862aa04ead7908c2316485c486fea81
lib/com.ibm.ws.app.manager.rar_1.0.14.jar=b19b9530e0b087b633d9b8da22e27136
lib/com.ibm.ws.jca-1.7_1.0.14.jar=64e26f88cf00d3f732783a872cf3f645
