#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.serverStatus-1.0.mf=bd309d58d4126e726e1186b291b4e143
lib/com.ibm.ws.serverstatus_1.0.14.jar=ec2ce789a822f5f59825273c35b6633a
