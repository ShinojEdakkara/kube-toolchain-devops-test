#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.ejbLite-3.1.mf=e8bba16c31092b27067d1b1f8e324cc1
