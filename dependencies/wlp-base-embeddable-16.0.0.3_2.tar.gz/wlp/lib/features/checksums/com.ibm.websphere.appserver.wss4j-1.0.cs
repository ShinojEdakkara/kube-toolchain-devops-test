#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.wss4j-1.0.mf=3a2a1cecad9feed0124dcfc200a6cbc6
lib/com.ibm.ws.xmlsec.1.5.2_1.0.14.jar=adcc2317259134bcf6f3ed7619c53458
lib/com.ibm.ws.wss4j.1.6.7_1.0.14.jar=3813aac26be384193d4584c1558f8b57
