#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.org.apache.commons.collections.3.2.1_1.0.14.jar=56f7947937a356126b950310c7c1be1e
lib/com.ibm.ws.jpa_1.2.14.jar=4c0d12c08bc8221b8ad2f2a348e4d88b
lib/com.ibm.ws.org.apache.commons.pool.1.5.4_1.0.14.jar=85919189f4422c5d6733cf5438d5b214
lib/com.ibm.ws.org.apache.commons.lang.2.4_1.0.14.jar=0567390140b1ef79ad2c4291c1150cb0
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.jpa_1.3.14.jar=ad17d2301bcdc2d5c1d782ea5b427b94
lib/com.ibm.ws.jpa.container.wsjpa_1.0.14.jar=c87f172b32cff97fe7a224f847677e72
lib/features/com.ibm.websphere.appserver.jpa-2.0.mf=77784ee675761564e89256c03dcebd7e
lib/com.ibm.ws.net.sourceforge.serp.1.15.1_1.0.14.jar=349d5a00c63e0fcfcfd1d5fcaf558c88
lib/com.ibm.ws.jpa.container_1.0.14.jar=75b7c650f7105b5037b62d3b57d5d7c8
