#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.internal.jms-1.1.mf=038d1b8dee98ea8e7377cebfe4aff804
lib/com.ibm.ws.messaging.jmsspec.common_1.0.14.jar=f20c2f7b3c9a80947609efc609c179ef
dev/api/spec/com.ibm.ws.javaee.jms.1.1_1.0.14.jar=28b03b5679e507d6b63a6d545e2fb81d
