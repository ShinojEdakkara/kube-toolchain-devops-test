#Wed Aug 31 18:32:08 BST 2016
bin/tools/ws-client.jar=9e447d30160c8e825a8505721f9af0c4
lib/features/com.ibm.websphere.appclient.client-1.0.mf=5af120a8d2f64ebb4ad2640afd3c0947
lib/com.ibm.ws.appclient.boot_1.0.14.jar=2899b40d823a7a480482433a1d0feb28
