#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=03c92c90e1965d2f75bf948ddb7ff162
lib/com.ibm.ws.jaxrs-2.0.appSecurity_1.0.14.jar=6ccb4384f409e8ac3b16ff0663c49ba8
