#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.wsoc11_1.0.14.jar=3403071801eebcdf5e8b487f31652aae
lib/com.ibm.ws.wsoc_1.0.14.jar=5e9ed2a0ef3d543ca045701ad142efa7
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=598a35ad8ce8750dc3ed57f4f033a935
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=b8acdbb529ce5a4e0073b21b19bcf455
dev/api/spec/com.ibm.ws.javaee.websocket.1.1_1.0.14.jar=59517cc8b63fe2529e9057546dd21399
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.14.jar=3051208a4eba0e10934bd844c6b84608
