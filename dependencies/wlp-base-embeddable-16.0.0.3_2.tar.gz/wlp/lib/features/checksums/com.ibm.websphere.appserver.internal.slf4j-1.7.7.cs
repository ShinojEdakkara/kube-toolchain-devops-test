#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=bbd0a7d66781f3909a69ae80919c3d75
lib/com.ibm.ws.slf4j-api.1.7.7_1.0.14.jar=0cb399847647473f5e4c79e17422288c
lib/com.ibm.ws.slf4j-jdk14.1.7.7_1.0.14.jar=fd5f86bf9c7ab56f05a866a0c2ce138f
