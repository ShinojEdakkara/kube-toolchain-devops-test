#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.wsoc.cdi.weld_1.0.14.jar=e3708dbe089aec69f1e7d24adc87bfe4
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=eeb31f361ee78cfe8c2f93f43d534cea
