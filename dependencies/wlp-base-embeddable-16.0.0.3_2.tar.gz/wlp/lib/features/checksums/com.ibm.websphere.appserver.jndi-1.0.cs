#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.jndi_1.0.14.jar=e3e7311a871bb17a3f6ec9e8587621d3
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=548b4b2897031df7382b42099b080561
lib/com.ibm.ws.org.apache.aries.jndi.core.1.0.3_1.1.14.jar=e9c42bef43140a679d8253885139539e
lib/com.ibm.ws.jndi.url.contexts_1.0.14.jar=43d31b04fda577074bac2dcbbbaa6907
lib/com.ibm.ws.org.apache.aries.jndi.api.1.1.1_1.1.14.jar=cc7465ff3a1f12c097caf9a618359eeb
