#Wed Aug 31 18:32:08 BST 2016
dev/api/spec/com.ibm.ws.javaee.jsp.2.3_1.0.14.jar=78a5584c7c5f4ec56ce55dd8a7f32726
lib/com.ibm.ws.cdi-1.2.web_1.0.14.jar=c27625790810467d2f073e76dad1b951
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=88fa53bfdac5a7c93ff1ddf078355a98
