#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.cdi1.0-transaction1.1.mf=f620afeac00fb514df13f4db4e161403
lib/com.ibm.ws.openwebbeans-transaction.1.1.6_1.0.14.jar=87506a2335b2dd969e87ac67f9bfff22
lib/com.ibm.ws.openwebbeans-ee.1.1.6_1.0.14.jar=9e6f7cf82e5ed2906b2937ba33d8c00b
