#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.sip.servlet-3.1.mf=1a63f1a0d9d2f9b5ebec359def4f0260
lib/com.ibm.ws.sip.container.servlet31_1.0.14.jar=218eecbd654d866aa515a0a3787e82d6
