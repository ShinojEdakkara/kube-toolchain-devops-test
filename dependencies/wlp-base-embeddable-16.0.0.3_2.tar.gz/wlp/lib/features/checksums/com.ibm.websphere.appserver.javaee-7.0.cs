#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.javaee-7.0.mf=cd7aa4361029f44e7840a44e576b86f7
