#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jpa2.0-bv1.0.mf=37b2f901bae95fabddfc8dab20a00278
lib/com.ibm.ws.jpa.container.beanvalidation_1.0.14.jar=e98de8e46a94486cfbe98b6bb9398caf
