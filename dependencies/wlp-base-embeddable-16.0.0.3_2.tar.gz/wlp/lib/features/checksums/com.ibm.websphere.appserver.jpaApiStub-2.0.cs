#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jpaApiStub-2.0.mf=a958d02782ec14e099b86b39cf0b7677
dev/api/third-party/com.ibm.ws.jpa_1.2.14.jar=fc084c70d8c2b25004831096868f08a6
