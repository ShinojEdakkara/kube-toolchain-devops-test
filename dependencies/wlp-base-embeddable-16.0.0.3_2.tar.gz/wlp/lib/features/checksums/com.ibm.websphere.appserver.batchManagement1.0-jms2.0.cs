#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.batchManagement1.0-jms2.0.mf=1751fa641fb1d6c149a6b2cadefbe455
lib/com.ibm.ws.jbatch.jms_1.0.14.jar=16d66bb829e308a00b3b3f069cec1f2a
