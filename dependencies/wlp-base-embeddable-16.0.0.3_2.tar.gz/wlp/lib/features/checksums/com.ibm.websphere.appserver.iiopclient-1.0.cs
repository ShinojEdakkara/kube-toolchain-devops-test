#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.iiopclient-1.0.mf=da42db38860d74e50b53d90c6fd343af
lib/com.ibm.ws.transport.iiop.client_1.0.14.jar=920264b88b12e2ceea5c5f76544b9061
