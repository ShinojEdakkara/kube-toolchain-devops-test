#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jca-1.6.mf=6c0f996870e1e809c3625cb854a37f49
lib/com.ibm.ws.app.manager.rar_1.0.14.jar=b19b9530e0b087b633d9b8da22e27136
