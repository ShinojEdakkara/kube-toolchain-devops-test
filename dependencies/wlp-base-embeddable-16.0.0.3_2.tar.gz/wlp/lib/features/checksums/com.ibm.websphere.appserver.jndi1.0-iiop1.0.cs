#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.jndi1.0-iiop1.0.mf=0488294c623709674cdd270f268ffd9e
lib/com.ibm.ws.jndi.iiop_1.0.14.jar=81ee1f5b336136fe97a5b08f7169f95a
