#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.org.apache.aries.jpa.container.1.0.4_1.1.14.jar=8506f9a7142889696967586af6565e90
lib/com.ibm.ws.eba.jpa.wab.integration_1.0.14.jar=c883137693dc32264f72e1efc4bc8493
lib/com.ibm.ws.org.apache.aries.jpa.container.context.1.0.5_1.1.14.jar=730d398d9caf393982c56b30e8e0a3aa
lib/features/com.ibm.websphere.appserver.osgi.jpa-1.1.mf=6ea3caec6e2bf7b8a9ddc1d4b190b2b6
lib/com.ibm.ws.eba.jpa.lookup_1.0.14.jar=be55c8deb71c133935f521158646e24d
lib/com.ibm.ws.org.apache.aries.jpa.blueprint.aries.1.0.5_1.1.14.jar=8fe0e2fef82be2f42146f9e2e6ae93c3
lib/com.ibm.ws.org.apache.aries.jndi.url.1.1.1_1.1.14.jar=a6b1c2741982b4a39440bc179d9e1bdf
lib/com.ibm.ws.eba.jpa.container.annotations_1.0.14.jar=07d47922ac2ca9754c070cb3b653edb5
lib/com.ibm.ws.org.apache.aries.jpa.api.1.0.3_1.1.14.jar=e76c603fb9eb7d33cfd09203fe04372e
