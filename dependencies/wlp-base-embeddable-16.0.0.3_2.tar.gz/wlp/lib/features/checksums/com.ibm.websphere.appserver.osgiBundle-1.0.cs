#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.osgiBundle-1.0.mf=a4846278e4f4faf008465a6e84c23ff2
lib/com.ibm.ws.eba.app.integration_1.0.14.jar=1fa4be23e8ff974be0994014855f3027
dev/api/spec/com.ibm.ws.org.osgi.service.cm.1.5.0_1.0.14.jar=e20811f2dd00e487b2eaa75ea27cefe2
