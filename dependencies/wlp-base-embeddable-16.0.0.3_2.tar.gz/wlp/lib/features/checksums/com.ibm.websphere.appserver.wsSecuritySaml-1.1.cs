#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.wssecurity.saml_1.0.14.jar=82e6783cfc57fc0ae5f9c05bd6be5ba5
lib/features/com.ibm.websphere.appserver.wsSecuritySaml-1.1.mf=9bd353923b43d660a1b4348dea897aab
