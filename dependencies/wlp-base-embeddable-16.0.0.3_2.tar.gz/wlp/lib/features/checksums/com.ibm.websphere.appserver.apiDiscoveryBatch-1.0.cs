#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.rest.api.discovery.batch_1.0.14.jar=bf3cedf0c29fcea40d0022f7ff50bc52
lib/features/com.ibm.websphere.appserver.apiDiscoveryBatch-1.0.mf=89c70e994f8a972f916dc58c2b1f4fbc
