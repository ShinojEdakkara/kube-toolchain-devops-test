#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.jaxrs-2.0.managedBeans_1.0.14.jar=39e0b9a9320c60f59df92c0572ab515e
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=c9a3a57bec565ed3c6001ad9e99ec7ac
