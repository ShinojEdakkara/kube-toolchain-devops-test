#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.wsat.webclient_1.0.14.jar=520744bbdf95c4630283852256d83b35
lib/com.ibm.ws.wsat.webservice_1.0.14.jar=7d3fedb947904a641c3b695830458145
lib/features/com.ibm.websphere.appserver.wsATWebService-1.0.mf=51c84666e7573f90f7638b3cb372bd45
