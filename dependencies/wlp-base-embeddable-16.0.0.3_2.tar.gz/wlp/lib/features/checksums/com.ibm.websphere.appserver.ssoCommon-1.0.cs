#Wed Aug 31 18:32:08 BST 2016
dev/spi/ibm/com.ibm.websphere.appserver.spi.saml20_1.0.14.jar=94ca39f46e791c1fdfbc77bbed6950ef
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.saml20_1.1-javadoc.zip=71d5b362f2d6033d4dc7c0f16b6eb042
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.saml20_1.0-javadoc.zip=e72472b34d1102d5cec964a2e755fdde
dev/api/ibm/com.ibm.websphere.appserver.api.saml20_1.1.14.jar=06ed6c0619a23776d0f09fac840e3f15
lib/features/com.ibm.websphere.appserver.ssoCommon-1.0.mf=1dbff4ae403445423405a754779b600e
lib/com.ibm.ws.security.sso.common_1.0.14.jar=ff941d66d982a2130b817cad2263435b
