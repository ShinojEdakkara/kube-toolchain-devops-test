#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.sip.monitor-1.0.mf=17d4078c67eb288716faf02939b81b65
lib/com.ibm.ws.sip.monitor_1.0.14.jar=1a5e1741b229973d478823702553f629
