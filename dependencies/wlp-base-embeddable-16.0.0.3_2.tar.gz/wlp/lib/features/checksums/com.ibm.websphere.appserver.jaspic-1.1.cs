#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.security.jaspic-1.1_1.0.14.jar=aa234e53db082aec3e7d382c1ef220d4
dev/spi/ibm/com.ibm.websphere.appserver.spi.jaspic_1.1.14.jar=43d4cdbd15edb427110c1c8434653c06
dev/api/spec/com.ibm.ws.javaee.jaspic.1.1_1.0.14.jar=e32bd866ff799f4473143dab43581bc4
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jaspic_1.1-javadoc.zip=2f4f5f917a19009904830b457bdef623
lib/features/com.ibm.websphere.appserver.jaspic-1.1.mf=3a217ecad28cb826c4fee0b53c2ad4ab
