#Wed Aug 31 18:32:08 BST 2016
dev/api/spec/com.ibm.ws.org.osgi.service.http.whiteboard.1.0.0_1.0.14.jar=4b507946772825510ce9b028773e16df
lib/features/com.ibm.websphere.appserver.httpWhiteboard-1.0.mf=b05cd70a5a44c1e863449a2509545fcf
dev/api/spec/com.ibm.ws.org.osgi.service.http.1.2.1_1.0.14.jar=69c1296ef0f9b3b7159463b4fc3a1b6e
lib/com.ibm.ws.http.whiteboard_1.0.14.jar=1b8e9b4fec6e17de3347f0880b5afe04
lib/com.ibm.ws.org.apache.aries.subsystem.api.2.0.9_1.0.14.jar=cea0f2bcde54f53c11c2166bf6a3c3bf
