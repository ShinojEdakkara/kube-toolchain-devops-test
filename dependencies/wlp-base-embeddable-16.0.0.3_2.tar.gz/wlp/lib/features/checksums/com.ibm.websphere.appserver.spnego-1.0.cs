#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.security.spnego_1.0.14.jar=ec7432f6fb6768dceab8f4256b490ffa
lib/features/com.ibm.websphere.appserver.spnego-1.0.mf=8301f138224ac1b4a19ffe75b145ae66
