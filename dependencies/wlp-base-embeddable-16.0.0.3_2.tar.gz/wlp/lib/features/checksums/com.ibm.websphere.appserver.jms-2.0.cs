#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.jms20.feature_1.0.14.jar=ad0e64d3d8d49acb3fe158a06e55b00c
lib/features/com.ibm.websphere.appserver.jms-2.0.mf=3444496fcb8f5d22dccc349734c04e09
