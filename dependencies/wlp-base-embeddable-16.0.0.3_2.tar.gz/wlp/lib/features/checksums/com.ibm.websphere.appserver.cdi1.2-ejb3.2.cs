#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.cdi-1.2.ejb_1.0.14.jar=ca8c5404c27ea9741646e97aae09b20b
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=4a8f70ffbccb932e90fdca3b15fa0043
