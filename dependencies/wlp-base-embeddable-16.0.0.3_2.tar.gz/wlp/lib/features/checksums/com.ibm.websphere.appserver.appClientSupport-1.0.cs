#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.appClientSupport-1.0.mf=e2596d961b1c30c014f9953c0feee06b
