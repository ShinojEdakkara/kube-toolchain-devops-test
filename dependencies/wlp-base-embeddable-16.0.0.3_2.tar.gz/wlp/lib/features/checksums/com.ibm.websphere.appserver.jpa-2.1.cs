#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.jpa.container_1.0.14.jar=75b7c650f7105b5037b62d3b57d5d7c8
lib/com.ibm.ws.jpa.container.v21_1.0.14.jar=cc623bbaa391d6fb5a387d6b1f1a250f
lib/com.ibm.ws.jpa.container.eclipselink_1.0.14.jar=0a9c29c1ec86b0dcdcb953913a1c3688
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=2c14c84d56b6c59ec536e3046627dc60
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.14.jar=92e92c66482d06a8e50bd2e77761f7a7
