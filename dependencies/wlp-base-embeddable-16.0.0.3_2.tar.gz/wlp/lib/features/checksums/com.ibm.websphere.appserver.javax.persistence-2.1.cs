#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.14.jar=dcf692e8d41a8422f54ba88647ae4db3
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=513c99e177f9578e9e62700cc9ac9c18
dev/api/spec/com.ibm.ws.javaee.persistence.dev.2.1_1.0.14.jar=1eb597e06fe74482d4a98dc2a56f7005
