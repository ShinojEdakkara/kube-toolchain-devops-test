#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.localConnector-1.0.mf=13a0c9979404e7770e91b0e0f9185312
lib/com.ibm.ws.jmx.connector.local_1.0.14.jar=ee7f0b59adaa57c00d338bfbb5c13af6
