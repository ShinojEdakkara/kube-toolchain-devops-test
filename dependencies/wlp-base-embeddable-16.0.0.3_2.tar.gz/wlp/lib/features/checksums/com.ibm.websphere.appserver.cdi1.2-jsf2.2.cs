#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=05f33d70f028cd94c94f2dcd62672447
lib/com.ibm.ws.cdi-1.2.jsf_1.0.14.jar=7b323a1a458f72d5715779f7aef0394b
