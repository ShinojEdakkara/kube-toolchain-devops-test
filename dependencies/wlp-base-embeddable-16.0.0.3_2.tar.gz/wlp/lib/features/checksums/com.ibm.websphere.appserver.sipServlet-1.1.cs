#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.app.manager.sar_1.0.14.jar=47e665e6041f7db148ba1bd5dabd52bc
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sipServlet.1.1_1.0-javadoc.zip=7ef9514bd08dbfdd30228fbc0c366335
lib/com.ibm.ws.sipcontainer_1.0.14.jar=14c23a40ffcacf7cffe3940a15a8cb7e
dev/api/ibm/com.ibm.websphere.appserver.api.sipServlet.1.1_1.0.14.jar=a218575b226050b422029415ebdba9d6
lib/features/com.ibm.websphere.appserver.sipServlet-1.1.mf=72c921a46d5124a39f3171adf2298611
dev/api/spec/com.ibm.ws.java.sipServlet.1.1_1.0.14.jar=363dbc50a3e9546ff0a823ea9d85fd01
