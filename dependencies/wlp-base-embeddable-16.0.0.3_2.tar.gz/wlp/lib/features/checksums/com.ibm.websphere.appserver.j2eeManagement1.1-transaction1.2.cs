#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.transaction.management_1.0.14.jar=cc3d3469c6b6862495248864cf341b97
lib/features/com.ibm.websphere.appserver.j2eeManagement1.1-transaction1.2.mf=6cf3a436a8db9c07c4e1c6ea6397de04
