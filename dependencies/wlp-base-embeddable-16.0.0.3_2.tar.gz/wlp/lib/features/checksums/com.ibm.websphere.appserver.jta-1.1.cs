#Wed Aug 31 18:32:08 BST 2016
dev/api/spec/com.ibm.ws.javaee.transaction.1.1_1.0.14.jar=30226a245265647b78b94828c6f8109a
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.14.jar=64a83fd909a98a23d97db131630a9a0b
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=d4fd215319d96c6d5825ade570020d1c
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=75191880e7139bd7d6ad53c10a05b1fc
