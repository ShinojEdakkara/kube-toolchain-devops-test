#Wed Aug 31 18:32:08 BST 2016
dev/spi/ibm/com.ibm.websphere.appserver.spi.wsat_1.0.14.jar=97e56f5e58560bdf6bad44785c88b227
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.wsat_1.0-javadoc.zip=3ab5ca51a188223edc0dc4b875c68559
lib/features/com.ibm.websphere.appserver.wsAtomicTransaction-1.2.mf=c7becdb604c05b6f51c21da048e0e556
lib/com.ibm.ws.wsat.common_1.0.14.jar=61c6a69bf1b8e3c1dd292e181d414287
