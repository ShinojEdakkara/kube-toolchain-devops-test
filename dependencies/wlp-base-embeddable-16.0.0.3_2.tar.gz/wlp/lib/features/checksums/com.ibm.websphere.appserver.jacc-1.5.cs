#Wed Aug 31 18:32:07 BST 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jacc_1.0-javadoc.zip=eb830104fc4e5f8c0886d13bcedc0569
lib/features/com.ibm.websphere.appserver.jacc-1.5.mf=6e59b9ab4f4e78fa1844eb62f284e720
dev/api/ibm/com.ibm.websphere.appserver.api.jacc_1.0.14.jar=91e7f021f86bc6736d5d01435eb1b6d6
dev/api/spec/com.ibm.ws.javaee.jacc.1.5_1.0.14.jar=e1daf41ddeea67a0c0c3e319357ddf14
lib/com.ibm.ws.security.authorization.jacc_1.0.14.jar=b73ea709101ab2e3b57e2771f3452911
