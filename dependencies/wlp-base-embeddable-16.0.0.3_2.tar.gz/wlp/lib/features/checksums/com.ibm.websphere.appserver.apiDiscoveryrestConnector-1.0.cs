#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.apiDiscoveryrestConnector-1.0.mf=9ecb5a98ffe11cbd96e5859d22848d5e
lib/com.ibm.ws.rest.api.discovery.jmx_1.0.14.jar=ec76803def1ef7a8a9cfdadbedc0b65c
