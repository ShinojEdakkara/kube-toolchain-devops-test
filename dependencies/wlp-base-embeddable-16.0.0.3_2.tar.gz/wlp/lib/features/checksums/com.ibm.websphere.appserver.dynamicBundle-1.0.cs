#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.dynamic.bundle_1.0.14.jar=93b743e739335f7b05918cd5b21b5c36
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=190cdc58a076da663755d97bbf14dda3
