#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=27fa072358297565a5df0e711784e4f4
lib/com.ibm.ws.jpa.container.beanvalidation11_1.0.14.jar=57c4196c250ec0b3a1ced179e91faa3e
