#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.swaggerJaxrs-1.0.mf=981efbb80ade0640b2d8129786b27653
lib/com.ibm.ws.io.swagger.jaxrs_1.0.14.jar=e85e038131e8de41f4e073925847dabd
