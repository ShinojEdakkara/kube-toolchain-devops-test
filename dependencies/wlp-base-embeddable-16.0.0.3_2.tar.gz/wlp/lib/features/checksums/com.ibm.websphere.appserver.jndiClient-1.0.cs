#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.jndi.remote.client_1.0.14.jar=06c867bb0c4f74bee27d99363452f0ba
lib/features/com.ibm.websphere.appserver.jndiClient-1.0.mf=8686e5766f163c188482a73a97007495
