#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=1b8fdaf1027907ffff7dc6c8389783bf
dev/api/spec/com.ibm.ws.javaee.ejb.3.1_1.0.14.jar=7506158228782e7d5fe7458de3acdd56
