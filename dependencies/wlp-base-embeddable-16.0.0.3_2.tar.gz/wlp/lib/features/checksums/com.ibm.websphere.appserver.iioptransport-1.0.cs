#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.iioptransport-1.0.mf=61085f59e7a478317f981c198cdf2db6
lib/com.ibm.ws.transport.iiop.server_1.0.14.jar=9cf1e696c6ffea1b6a3775cfa175198b
