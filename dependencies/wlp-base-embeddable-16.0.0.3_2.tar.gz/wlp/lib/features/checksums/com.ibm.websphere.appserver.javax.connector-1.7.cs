#Wed Aug 31 18:32:07 BST 2016
dev/api/spec/com.ibm.ws.javaee.connector.1.7_1.0.14.jar=2b3aa8d0f4bee32f9624d75913b613cf
lib/features/com.ibm.websphere.appserver.javax.connector-1.7.mf=0304045a63677509f807220ee5ded02f
