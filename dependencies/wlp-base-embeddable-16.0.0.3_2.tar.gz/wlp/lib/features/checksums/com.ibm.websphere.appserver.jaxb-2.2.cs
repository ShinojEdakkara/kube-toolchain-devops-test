#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.jaxb-2.2.mf=2a39bdb3081501127f37912b23ae844b
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.14.jar=055c4752e4ca95bfbeb32263ca2d0ec0
dev/api/spec/com.ibm.ws.javaee.jaxb.2.2_1.0.14.jar=51a531091c0955b13c992db8ac8bdffc
bin/jaxb/tools/ws-xjc.jar=99561377e90b98c50e4b1facbb126518
lib/com.ibm.ws.xlxp.1.5.3_1.0.14.jar=6a54a92d4773cab11053f31948596121
bin/jaxb/tools/ws-schemagen.jar=aa9686173051b0b61b827045edda4bb8
lib/com.ibm.ws.org.apache.geronimo.specs.geronimo-osgi-registry.1.1_1.0.14.jar=a9e09f2db3a7c359204186e0571b8820
