#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=46efe31308bf1255215525eba0b9c7ae
lib/com.ibm.ws.ejbcontainer.session_1.0.14.jar=10a4a00c4a55764d766966346028312b
