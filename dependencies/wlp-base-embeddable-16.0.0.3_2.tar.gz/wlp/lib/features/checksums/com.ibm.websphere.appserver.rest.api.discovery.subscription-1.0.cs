#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.rest.api.discovery.subscription_1.0.14.jar=207c45ecf8fae925df70381f5a735719
lib/features/com.ibm.websphere.appserver.rest.api.discovery.subscription-1.0.mf=887d846f561bb1515c8fbc8843b077bf
