#Wed Aug 31 18:32:08 BST 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sipServletSecurity.1.0_1.0-javadoc.zip=a1f93f1f6bee0c3a46c08847870697a3
lib/com.ibm.ws.security.authentication.tai_1.0.14.jar=3a39c28a64697b80f514870e9b549721
lib/features/com.ibm.websphere.appserver.sip.security-1.0.mf=2dda1c32dbefe51c28d16cdac66adc80
lib/com.ibm.ws.sip.security_1.0.14.jar=48b0c848990dde6a7edc707e2e2573bc
dev/api/ibm/com.ibm.websphere.appserver.api.sipServletSecurity.1.0_1.0.14.jar=24b0671f4cc10d54a96e8cffe0a19ac1
