#Wed Aug 31 18:32:07 BST 2016
dev/api/spec/com.ibm.ws.javaee.management.j2ee.1.1_1.0.14.jar=b715ce9dd52ed08e181dc43476e89b35
lib/features/com.ibm.websphere.appserver.j2eeManagementClient-1.1.mf=28654463447535b4288a61bba9800aca
