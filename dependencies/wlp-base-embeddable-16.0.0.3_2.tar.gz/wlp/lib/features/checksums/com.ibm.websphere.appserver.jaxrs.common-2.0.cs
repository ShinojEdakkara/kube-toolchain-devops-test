#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.jaxrs-2.0.tools_1.0.14.jar=92016fdd958a2b99073720c14736594d
lib/com.ibm.ws.jaxrs-2.0.common_1.0.14.jar=2cab0436c3ef2428bcb8c44f4a2b8cb0
dev/api/spec/com.ibm.ws.javaee.jaxrs.2.0_1.0.14.jar=53036b05db88da3e379ae393be25dc73
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=fc4b093d65ecce78a07f2a4ec4c2a25c
lib/com.ibm.ws.org.apache.xml-resolver.1.2_1.0.14.jar=be425bbf30cccd571995585af765068e
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.14.jar=fea63506b080a503f2fbb05475caf488
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.14.jar=685d916280e4f553a9d8144eabbcf804
bin/jaxrs/tools/wadl2java.jar=af132575097bd6f621d096550761efb8
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.14.jar=319097524ed3f4421e8338fd5ce307d5
lib/features/com.ibm.websphere.appserver.jaxrs.common-2.0.mf=b11faaef242d7b970037da9931b6642a
