#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jaxwsejb-2.2.mf=5f4b288d18339467e9f8cb05e34b4d51
lib/com.ibm.ws.jaxws.ejb_1.0.14.jar=c777f938a8ca768ba643e93b9f2ed2f1
