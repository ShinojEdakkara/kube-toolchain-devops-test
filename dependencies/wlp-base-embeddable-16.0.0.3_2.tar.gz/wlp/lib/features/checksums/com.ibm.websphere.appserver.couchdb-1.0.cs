#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.couchdb_1.0.14.jar=2977f862c92bcf0b0ea25454e0155e61
lib/features/com.ibm.websphere.appserver.couchdb-1.0.mf=b17f6687cb0194931199a02a573d5399
