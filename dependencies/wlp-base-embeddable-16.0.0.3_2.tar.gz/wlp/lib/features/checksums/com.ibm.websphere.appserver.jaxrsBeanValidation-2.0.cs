#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.jaxrs-2.0.beanValidation_1.0.14.jar=8fe4da206d89223dfa4a47e4b3caf430
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=ea75efc5edc01daa533a41c46254d59d
