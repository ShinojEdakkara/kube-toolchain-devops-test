#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.cloudant_1.0.14.jar=92aae129b7c163b580b67b5cb65405df
lib/com.ibm.ws.security.auth.data.common_1.0.14.jar=adc8c624a0e38c354038d7ffa4dc37bb
lib/features/com.ibm.websphere.appserver.cloudant-1.0.mf=4cb750ac7251b0275fbb50d839632bba
