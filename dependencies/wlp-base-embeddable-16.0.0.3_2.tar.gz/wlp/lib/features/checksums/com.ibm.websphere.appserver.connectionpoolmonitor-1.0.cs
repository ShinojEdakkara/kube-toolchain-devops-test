#Wed Aug 31 18:32:08 BST 2016
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.14.jar=4f3ff46c4f17252ef68b970c87a34c16
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=c43a4c8ce40047041dd2830eb18bbcd1
lib/com.ibm.ws.connectionpool.monitor_1.0.14.jar=bd928e3d143eaff1795ffc2413aa5d01
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=32e0ba0617f2e8a910a80aa7221c37b5
