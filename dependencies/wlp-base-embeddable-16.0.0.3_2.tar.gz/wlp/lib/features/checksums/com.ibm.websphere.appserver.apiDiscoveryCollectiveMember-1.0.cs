#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.apiDiscoveryCollectiveMember-1.0.mf=cc816afe8c9021cb8211cf1db95db9f7
lib/com.ibm.ws.rest.api.discovery.collective.member_1.0.14.jar=b01c20e7ae4877b9cb266322c16ec5ef
