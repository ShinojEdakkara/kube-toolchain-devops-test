#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jca.resourcedefinition.jms-2.0.mf=c2ad9764326a4fffeaa2ad808c8037d2
lib/com.ibm.ws.jca.resourcedefinition.jms-2.0_1.0.14.jar=84cda9061d6a5aff4de7f026f636c01f
