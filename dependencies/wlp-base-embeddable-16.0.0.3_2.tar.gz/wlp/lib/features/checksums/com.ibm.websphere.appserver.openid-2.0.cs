#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.openid-2.0.mf=1916ecf8d094403212c874d23e83452b
lib/com.ibm.ws.openid4java.0.9.7_1.0.14.jar=353334ac43476d8e6e8eeab4d6597995
lib/com.ibm.ws.security.openid20_1.0.14.jar=87da2c3b35f9ceff765eb5824dbe815f
lib/com.ibm.ws.nekohtml.1.9.18_1.0.14.jar=1655e78134236a52ec5867b71004b81b
lib/com.ibm.ws.org.apache.xml-resolver.1.2_1.0.14.jar=be425bbf30cccd571995585af765068e
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.14.jar=c5d32bbd434cb7607b6ba95cc896fe75
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.14.jar=90834a983398a51631b15c8bc5d3b048
lib/com.ibm.ws.guice.2.0_1.0.14.jar=cc3f7a6150d58e3455df183533baa1e1
