#Wed Aug 31 18:32:07 BST 2016
dev/api/spec/com.ibm.ws.javaee.connector.1.6_1.0.14.jar=05cef87bfebf55fd8b20ff1f4b5f60a0
lib/features/com.ibm.websphere.appserver.javax.connector-1.6.mf=ce5fd4aa709fb6b3c7aa1186715a7815
