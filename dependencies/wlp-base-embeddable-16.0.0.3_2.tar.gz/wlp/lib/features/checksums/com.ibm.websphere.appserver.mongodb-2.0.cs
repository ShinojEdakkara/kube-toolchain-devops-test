#Wed Aug 31 18:32:07 BST 2016
lib/com.ibm.ws.mongo_1.0.14.jar=9f206fbd2013a44fb3374f6f2cac5fb0
lib/features/com.ibm.websphere.appserver.mongodb-2.0.mf=aed9b3a68d61475c5cd6358c70dc7071
