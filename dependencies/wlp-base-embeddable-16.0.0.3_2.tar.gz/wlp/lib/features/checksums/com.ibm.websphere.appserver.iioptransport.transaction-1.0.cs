#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.iioptransport.transaction-1.0.mf=7d4d0fc45673e9793222b810ee0a2f8a
lib/com.ibm.ws.transport.iiop.transaction_1.0.14.jar=1142f9b279e55486d03d186d10f03281
