#Wed Aug 31 18:32:07 BST 2016
dev/spi/ibm/com.ibm.websphere.appserver.spi.oauth_1.4.14.jar=89af508bcf50e21976b2c3e4df7eaf68
lib/com.ibm.ws.org.json.simple.1.1.1_1.0.14.jar=013045c7a1d2d7a0c097fb5beb677b86
lib/com.ibm.ws.org.jose4j.0.5.1_1.0.14.jar=e7e27b12820d6fd9ec4df5210d02bba5
dev/api/ibm/com.ibm.websphere.appserver.api.oauth_1.2.14.jar=60a8bcdcae8c23a7ef6b50113e45c9e1
lib/features/com.ibm.websphere.appserver.oauth-2.0.mf=69d1084a5f7315d47bb78ab347f6158e
lib/com.ibm.ws.security.oauth20_1.1.14.jar=236b847bb69d65430263b7905abe9b85
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.oauth_1.4-javadoc.zip=f84f8a679d99e653ea8aa4c60081abc2
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.oauth_1.2-javadoc.zip=d84913f82553b4967ea94e214af70dce
lib/com.ibm.ws.gson.2.2.4_1.0.14.jar=f60aba4448bcf5d0aad205484f021c29
