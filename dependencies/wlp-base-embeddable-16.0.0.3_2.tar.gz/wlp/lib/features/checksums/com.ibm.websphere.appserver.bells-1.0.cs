#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.bells-1.0.mf=863228779818fcdc4058abc3fed27091
lib/com.ibm.ws.classloading.bells_1.0.14.jar=ebe878cf53b5d4ebfcee1ce5e0823a9f
