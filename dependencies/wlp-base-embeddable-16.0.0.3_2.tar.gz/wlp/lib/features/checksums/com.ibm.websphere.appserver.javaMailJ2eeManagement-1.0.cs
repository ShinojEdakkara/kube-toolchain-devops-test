#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.javaMailJ2eeManagement-1.0.mf=11b09da359717acd2152b427477b8cc3
lib/com.ibm.ws.javamail.management.j2ee_1.0.14.jar=dca853972d6aa6f4abd09cace296bfd6
