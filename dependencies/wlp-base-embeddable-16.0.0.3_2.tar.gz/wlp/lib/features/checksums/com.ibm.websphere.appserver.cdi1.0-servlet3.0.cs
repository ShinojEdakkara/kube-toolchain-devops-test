#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.cdi1.0-servlet3.0.mf=28a0376cc05b08dd7316e48f3b496579
lib/com.ibm.ws.openwebbeans-web.1.1.6_1.0.14.jar=070696d490b792c7be1d8becfc9a74b5
lib/com.ibm.ws.openwebbeans-ee-common.1.1.6_1.0.14.jar=0ba3686258bf545dbfcd2a510a21f91b
