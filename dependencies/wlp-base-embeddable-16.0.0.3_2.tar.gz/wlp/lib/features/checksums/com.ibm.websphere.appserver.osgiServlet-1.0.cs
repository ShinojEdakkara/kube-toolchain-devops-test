#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.osgiServlet-1.0.mf=aa3f7525c7f2579ce44e4613a7bbdba2
