#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jmsJ2eeManagement-1.0.mf=8d51487fdc1c3086b8561e4ec097e899
lib/com.ibm.ws.messaging.jms.j2ee.mbeans_1.0.14.jar=7a07f031a4d7780e7842d0619f66c84a
