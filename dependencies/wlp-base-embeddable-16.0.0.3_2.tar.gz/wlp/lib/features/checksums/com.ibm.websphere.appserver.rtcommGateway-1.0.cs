#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.rtcommGateway-1.0.mf=5bc14388384fedc276f24806be66a701
lib/com.ibm.ws.webrtc.gateway_1.0.14.jar=4beb04dee212587c0e40fb90bbb4c5ab
lib/com.ibm.ws.sip.ua_1.0.14.jar=92e97b0d63ad5aa2777d7dde27cf1df8
