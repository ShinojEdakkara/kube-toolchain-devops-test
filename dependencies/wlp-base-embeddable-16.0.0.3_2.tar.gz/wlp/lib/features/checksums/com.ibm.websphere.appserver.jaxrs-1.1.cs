#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrs-1.1.mf=f52cad8dfa47abde243ce220d92966c6
