#Wed Aug 31 18:32:08 BST 2016
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.14.jar=e173d996ae4ee7d40430bd5454f7b1c3
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=3e7db77fb1ef87dd965b2f1557917938
