#Wed Aug 31 18:32:07 BST 2016
lib/features/com.ibm.websphere.appserver.eventLogging-1.0.mf=a8ab6803ac2a258f1dff428726c9d8c5
lib/com.ibm.ws.event.logging_1.0.14.jar=3446607f0a1af61e0b297982aba34e16
