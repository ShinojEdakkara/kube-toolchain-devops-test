#Wed Aug 31 18:32:08 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=d269e4b098abcfb2c59d74029336ed19
